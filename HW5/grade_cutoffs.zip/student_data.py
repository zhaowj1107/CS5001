STUDENTS = [
    {
        'name': 'Alice Smith',
        'homework': [100, 92, 98, 100, 95, 93, 89, 91, 90, 0],
        'quizzes': [82, 83, 91, 80, 82, 85, 80, 0],
        'midterm': 89,
        'final': 93
    },
    {
        'name': 'Li Wei',
        'homework': [94, 85, 88, 0, 93, 87, 86, 90, 89, 92],
        'quizzes': [81, 76, 88, 84, 80, 82, 78, 80],
        'midterm': 86,
        'final': 88
    },
    {
        'name': 'Arjun Patel',
        'homework': [78, 0, 89, 92, 95, 92, 88, 89, 91, 93],
        'quizzes': [72, 78, 85, 80, 79, 77, 82, 81],
        'midterm': 81,
        'final': 87
    },
    {
        'name': 'Chidinma Okafor',
        'homework': [0, 90, 87, 88, 92, 94, 95, 91, 89, 92],
        'quizzes': [80, 84, 86, 85, 0, 80, 78, 81],
        'midterm': 85,
        'final': 84
    },
    {
        'name': 'Maria Hernandez',
        'homework': [95, 88, 90, 87, 92, 94, 93, 0, 91, 92],
        'quizzes': [0, 78, 82, 81, 80, 78, 77, 76],
        'midterm': 80,
        'final': 86
    },
    {
        'name': 'Jordan Tremblay',
        'homework': [88, 90, 91, 92, 93, 92, 91, 0, 89, 90],
        'quizzes': [76, 80, 81, 80, 78, 0, 76, 75],
        'midterm': 82,
        'final': 85
    },
    {
        'name': 'Clément Dubois',
        'homework': [90, 92, 85, 89, 88, 89, 87, 86, 85, 0],
        'quizzes': [72, 78, 80, 0, 76, 78, 79, 77],
        'midterm': 79,
        'final': 82
    },
    {
        'name': 'Sasha Ivanov',
        'homework': [89, 85, 88, 90, 0, 91, 92, 93, 89, 90],
        'quizzes': [70, 75, 80, 76, 77, 78, 0, 73],
        'midterm': 76,
        'final': 80
    },
    {
        'name': 'Yuki Tanaka',
        'homework': [88, 89, 85, 87, 86, 87, 88, 0, 86, 85],
        'quizzes': [68, 72, 74, 71, 0, 72, 73, 70],
        'midterm': 73,
        'final': 78
    },
    {
        'name': 'Sara Bjornsdottir',
        'homework': [87, 86, 84, 85, 86, 0, 85, 84, 83, 82],
        'quizzes': [65, 70, 75, 0, 73, 72, 71, 69],
        'midterm': 70,
        'final': 75
    }
]
