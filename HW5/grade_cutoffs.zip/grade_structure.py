GRADE_STRUCTURE = {
    'homework': {'weight': 0.15, 'drop_lowest': 1},
    'quizzes': {'weight': 0.15, 'drop_lowest': 1},
    'midterm': {'weight': 0.3},
    'final': {'weight': 0.4}
}
