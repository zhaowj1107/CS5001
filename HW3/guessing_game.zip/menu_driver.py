"""
File: menu_driver
Author: Weijian Zhao (David)
Date: 2025-01-27
Class: CS_5001, Spring_2025
Description: 
homework 2-1: System Functions and DateTime Menu
"""

import menu_functions as mf


def main():
    """
    Function main()
    Parameters: nothing
    Returns: None
    description: driver file and function
    """
    mf.run_menu()


if __name__ == "__main__":
    main()
